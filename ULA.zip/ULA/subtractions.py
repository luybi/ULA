for i in range(-8, 8):
    print("%2d: " % i, end="")
    
    for j in range(-8, 8):
        print("%8d " % (i - j), end="") if i - j in range(-8, 8) else print("\033[91m%8d \033[0m" % (i - j), end="")
    
    print()